package br.com.fiap.foodflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodflowApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodflowApplication.class, args);
	}

}
