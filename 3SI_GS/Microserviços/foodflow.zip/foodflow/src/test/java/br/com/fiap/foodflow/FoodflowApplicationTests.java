package br.com.fiap.foodflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
