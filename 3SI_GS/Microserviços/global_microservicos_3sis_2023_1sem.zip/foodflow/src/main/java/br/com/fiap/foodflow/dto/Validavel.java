package br.com.fiap.foodflow.dto;

public interface Validavel {
}
