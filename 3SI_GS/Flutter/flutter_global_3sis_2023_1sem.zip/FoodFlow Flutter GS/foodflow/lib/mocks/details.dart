const String _imageInitialPath = "assets/images";
const List<Object> details = [
  {
    "image": "$_imageInitialPath/coffee-beans.jpg",
    "id": "195515435616",
    "status": "Pronta para Colheita",
    "name": "Café Pilao",
    "typeOfCultivation": "Coffee Árabica",
    "pestsDetected": "Sem Indícios",
    "nutrientDeficiency": "Sódio e Potássio",
    "irrigationNeed": "Sim",
    "description":
        "Os resultados das análises indicam que a plantação está em ótimo estado."
  },
];
