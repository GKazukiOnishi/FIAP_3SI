const String _imagePath = "assets/images";
const List<Object> milhos = [
  {
    "image": "$_imagePath/corn-seed.jpg",
    "id": "195515485020",
    "name": "Milho Yoki",
    "typeOfCultivation": "Corn",
    "pestsDetected": "Pulgão",
    "nutrientDeficiency": "Nitrogênio",
    "irrigationNeed": "No"
  },
];
